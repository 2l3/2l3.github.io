<!DOCTYPE html>
<html>
<head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# website: http://ogp.me/ns/website#">
<title>بطاقات تهنئة - موقع مصدر</title>
<meta charset="UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<base href="https://imasdar.com/crd/eid/2/" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="Robots" content="index,follow" />
<meta name="application-name" content="Cards Maker" />
<meta name="msapplication-starturl" content="https://imasdar.com/crd/eid/2/" />

<meta property="fb:app_id" content="2042535152645154" />
<meta property="og:type" content="website" />
<meta property="og:title" content="بطاقات تهنئة - موقع مصدر" />
<meta property="og:description" content="بطاقات تهنئة - موقع مصدر" />
<meta property="twitter:title" content="بطاقات تهنئة - موقع مصدر" />
<meta property="twitter:description" content="بطاقات تهنئة - موقع مصدر" />
<meta property="twitter:site" content="cardsmaker" />
<meta property="og:url" content="https://imasdar.com/crd/eid/2/index.php" />
<meta http-equiv="cache-control" content="max-age=0" />
<meta http-equiv="cache-control" content="no-cache" />
<meta http-equiv="expires" content="0" />
<meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT" />
<meta http-equiv="pragma" content="no-cache" />
<link href="lib/bootstrap.min.css" rel="stylesheet" type="text/css" />
<!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
<link href="css/photo-editor.css?v=1.5" rel="stylesheet" type="text/css" />
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<link href="css/spectrum.css" rel="stylesheet" type="text/css" />
<script src="lib/jquery-3.2.1.min.js" type="text/javascript"></script>
<script src="lib/helpers.js" type="text/javascript"></script>
<script src="lib/jcanvas.min.js" type="text/javascript"></script>
<script src="lib/bootstrap.min.js" type="text/javascript"></script>
<script src="lib/photoEditor.js?v=1.5" type="text/javascript"></script>
<script src="lib/jquery-ui.js" type="text/javascript"></script>
<script src="lib/spectrum.js" type="text/javascript"></script>
<link href='https://fonts.googleapis.com/css?family=Amiri' rel='stylesheet'>
<link href='https://fonts.googleapis.com/css?family=Cairo' rel='stylesheet'>
<link href='https://fonts.googleapis.com/css?family=Rakkas' rel='stylesheet'>
<link href='https://fonts.googleapis.com/css?family=Lalezar' rel='stylesheet'>
<link href='https://fonts.googleapis.com/css?family=Vibes' rel='stylesheet'>
<link href='https://fonts.googleapis.com/css?family=Reem Kufi' rel='stylesheet'>
<link href='https://fonts.googleapis.com/css?family=Jomhuria' rel='stylesheet'>
<link href="css/google-fonts.css" rel="stylesheet" type="text/css" />
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<style type="text/css">
            #the-loading div
            {
                width: 0%;
                height: 5px;
            }
            #the-loading
            {
                position: fixed !important;
                z-index: 5;
                bottom: 0px;
                left: 0;
                right: 0;
                display: block;
            }
            #loadingForm
            {
                opacity: 0.8;
                background-color: #fff;
                position: fixed;
                z-index: 999999;
                display: none;
                top:0;
                bottom: 0;
                left: 0;
                right: 0;
                width: 100%;
                height: 100%;
                /*cursor: wait;*/            
            }
            #loadingForm div
            {
                background-color: #fff;
                background-position: center 20px;
                background-repeat: no-repeat;
                width: 420px;            
                padding-top: 120px;
                text-align: center;
                margin: auto;
                margin-top: 100px;
                border-radius: 10px;
            }
            


.AT-ads { position: fixed; bottom: 0; left: 0; width: 100%; min-height: 70px; max-height: 200px; padding: 5px 0; box-shadow: 0 -6px 18px 0 rgba(9,32,76,.1); -webkit-transition: all .1s ease-in; transition: all .1s ease-in; display: flex; align-items: center; justify-content: center; background-color: #fefefe; z-index: 20; } .AT-ads-close { width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; border-radius: 12px 0 0; position: absolute; right: 0; top: -30px; background-color: #fefefe; box-shadow: 0 -6px 18px 0 rgba(9,32,76,.08); } .AT-ads .AT-ads-close svg { width: 22px; height: 22px; fill: #000; } .AT-ads .AT-ads-content { overflow: hidden; display: block; position: relative; height: 70px; width: 100%; margin-right: 10px; margin-left: 10px; }

        </style>
</head>
<body>

<div id="loadingForm">
<div class="text-center">
<i class="fa fa-spinner fa-pulse fa-5x fa-fw"></i>
<span class="sr-only">Loading...</span>
</div>
</div>

<header class="navbar navbar-static-top navbar-inverse hide" id="top" role="banner">
<div class="container">
<div class="navbar-header">
<button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".bs-navbar-collapse">
<span class="sr-only">Toggle navigation</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a href="index.php" id="brand" class="navbar-brand">
بطاقات تهنئة </a>
</div>
<nav class="collapse navbar-collapse bs-navbar-collapse" role="navigation">
<ul class="nav navbar-nav navbar-right">
<li>
<a href="#" onclick="login();return false;">Login</a>
</li>
</ul>
</nav>
</div>
</header>
<div class="container">
<div class="col-md-12 text-center visible-lg">
</div>
<div class="clearfix"></div>
<div class='AT-ads jhfdiuh0' id='AT-ads'>
<div class='AT-ads-close' onclick='document.getElementById(&quot;AT-ads&quot;).style.display=&quot;none&quot;'><svg viewBox='0 0 512 512' xmlns='http://www.w3.org/2000/svg'><path d='M278.6 256l68.2-68.2c6.2-6.2 6.2-16.4 0-22.6-6.2-6.2-16.4-6.2-22.6 0L256 233.4l-68.2-68.2c-6.2-6.2-16.4-6.2-22.6 0-3.1 3.1-4.7 7.2-4.7 11.3 0 4.1 1.6 8.2 4.7 11.3l68.2 68.2-68.2 68.2c-3.1 3.1-4.7 7.2-4.7 11.3 0 4.1 1.6 8.2 4.7 11.3 6.2 6.2 16.4 6.2 22.6 0l68.2-68.2 68.2 68.2c6.2 6.2 16.4 6.2 22.6 0 6.2-6.2 6.2-16.4 0-22.6L278.6 256z' /></svg></div>
<div class='AT-ads-content'>
<ins class="adsbygoogle" style="display:inline-block;height:70px;width:100%;line-height:70px;" data-ad-client="ca-pub-1148445499813917" data-ad-slot="5342511111"></ins><script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>
</div>
<div class=" text-center">
<h1 id="site-title">
<a href="https://imasdar.com/" itemprop="url" rel="home">
<img id="site-logo" src="https://imasdar.com/wp-content/uploads/2021/01/logo-3.png" alt="مصدر" width="15%">
</a>
</h1>
</div>
<div class="text-center">
<h2><span style="color:#c0392b"><strong> اكتب اسمك على بطاقات معايدة بعيد الفطر المبارك </strong></span></h2>
</div>
<div style="clear:both" />
<br></br>
<div class=" text-right">
<p>بمناسبة عيد الفطر المبارك يمكنك&nbsp;<strong>كتابة اسمك أو اسم من تحب على صور&nbsp;تهنئة ومعايدة بعيد الفطر المبارك </strong>، فإننا في&nbsp;<a href="https://imasdar.com/" target="_blank"><strong>موقع مصدر</strong></a>&nbsp;نقدم إليكم مجموعة من أفضل التصميمات المميزة والتهاني بمناسبة عيد الفطر المبارك التي تكون جاهزة للتعديل عليها بطريقة سهلة وجميلة ومع القدرة على <span style="color:#ff0000"><strong>كتابة الاسم الاول والاخير</strong></span> وحفظ الصورة أو مشاركتها عبر وسائل التواصل الاجتماعي.</p>
<br></br>
<div class="col-md-12 text-center">

<ins class="adsbygoogle" style="display:inline-block;width:728px;height:90px" data-ad-client="ca-pub-1148445499813917" data-ad-slot="1594837797"></ins>
<script>
    (adsbygoogle = window.adsbygoogle || []).push({});
    </script>
</div>
<div class="clearfix"></div>
<br />
<div class="col-md-3" style="float: right;">
<a href="?photo=95_60846d0b7a708.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/95_60846d0b7a708.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/95_60846d0b7a708.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/95_60846d0b7a708.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=46_60846ce4d41f6.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/46_60846ce4d41f6.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/46_60846ce4d41f6.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/46_60846ce4d41f6.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=43_60846d60bce02.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/43_60846d60bce02.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/43_60846d60bce02.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/43_60846d60bce02.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=36_60846d0b7b564.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="left" data-html="true" data-content="<img style='width: 250px' src='__bgs__/36_60846d0b7b564.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/36_60846d0b7b564.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/36_60846d0b7b564.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=58_60846d60bb9e2.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/58_60846d60bb9e2.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/58_60846d60bb9e2.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/58_60846d60bb9e2.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=26_60846ce4d4343.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/26_60846ce4d4343.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/26_60846ce4d4343.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/26_60846ce4d4343.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=50_60846d60bbf36.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/50_60846d60bbf36.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/50_60846d60bbf36.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/50_60846d60bbf36.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=59_60846d39aadc2.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="left" data-html="true" data-content="<img style='width: 250px' src='__bgs__/59_60846d39aadc2.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/59_60846d39aadc2.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/59_60846d39aadc2.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=9_60846d0b7a250.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/9_60846d0b7a250.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/9_60846d0b7a250.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/9_60846d0b7a250.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=15_60846d39ab455.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/15_60846d39ab455.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/15_60846d39ab455.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/15_60846d39ab455.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=47_60846d60bc434.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/47_60846d60bc434.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/47_60846d60bc434.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/47_60846d60bc434.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=91_60846d39abf16.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="left" data-html="true" data-content="<img style='width: 250px' src='__bgs__/91_60846d39abf16.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/91_60846d39abf16.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/91_60846d39abf16.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=48_60846d60bb925.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/48_60846d60bb925.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/48_60846d60bb925.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/48_60846d60bb925.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=36_60846d39ac01e.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/36_60846d39ac01e.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/36_60846d39ac01e.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/36_60846d39ac01e.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
 <a href="?photo=43_60846d60bc6aa.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/43_60846d60bc6aa.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/43_60846d60bc6aa.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/43_60846d60bc6aa.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=19_60846d0b79e0f.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="left" data-html="true" data-content="<img style='width: 250px' src='__bgs__/19_60846d0b79e0f.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/19_60846d0b79e0f.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/19_60846d0b79e0f.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=60_60846d60bcbc2.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/60_60846d60bcbc2.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/60_60846d60bcbc2.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/60_60846d60bcbc2.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=59_60846ce4d4129.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/59_60846ce4d4129.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/59_60846ce4d4129.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/59_60846ce4d4129.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=78_60846d60bc1a0.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/78_60846d60bc1a0.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/78_60846d60bc1a0.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/78_60846d60bc1a0.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=43_60846d0b79ba2.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="left" data-html="true" data-content="<img style='width: 250px' src='__bgs__/43_60846d0b79ba2.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/43_60846d0b79ba2.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/43_60846d0b79ba2.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=66_60846d0b79c57.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/66_60846d0b79c57.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/66_60846d0b79c57.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/66_60846d0b79c57.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=89_60846ce4d3ee9.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/89_60846ce4d3ee9.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/89_60846ce4d3ee9.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/89_60846ce4d3ee9.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=20_60846ce4d44b2.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/20_60846ce4d44b2.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/20_60846ce4d44b2.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/20_60846ce4d44b2.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=91_60846d0b7b2fb.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="left" data-html="true" data-content="<img style='width: 250px' src='__bgs__/91_60846d0b7b2fb.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/91_60846d0b7b2fb.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/91_60846d0b7b2fb.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=88_60846d39ab273.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/88_60846d39ab273.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/88_60846d39ab273.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/88_60846d39ab273.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=35_60846d0b79ebe.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/35_60846d0b79ebe.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/35_60846d0b79ebe.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/35_60846d0b79ebe.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=44_60846d60bc35b.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/44_60846d60bc35b.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/44_60846d60bc35b.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/44_60846d60bc35b.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=6_60846ce4d35b4.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="left" data-html="true" data-content="<img style='width: 250px' src='__bgs__/6_60846ce4d35b4.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/6_60846ce4d35b4.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/6_60846ce4d35b4.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=26_60846d0b7a9df.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/26_60846d0b7a9df.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/26_60846d0b7a9df.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/26_60846d0b7a9df.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=7_60846d60bc277.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/7_60846d60bc277.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/7_60846d60bc277.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/7_60846d60bc277.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=91_60846ce4d3410.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/91_60846ce4d3410.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/91_60846ce4d3410.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/91_60846ce4d3410.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=48_60846d0b7b01a.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="left" data-html="true" data-content="<img style='width: 250px' src='__bgs__/48_60846d0b7b01a.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/48_60846d0b7b01a.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/48_60846d0b7b01a.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=6_60846ce4d4408.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/6_60846ce4d4408.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/6_60846ce4d4408.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/6_60846ce4d4408.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=39_60846d0b7a465.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/39_60846d0b7a465.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/39_60846d0b7a465.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/39_60846d0b7a465.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=61_60846d39abb9d.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/61_60846d39abb9d.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/61_60846d39abb9d.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/61_60846d39abb9d.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=11_60846d0b7ac0a.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="left" data-html="true" data-content="<img style='width: 250px' src='__bgs__/11_60846d0b7ac0a.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/11_60846d0b7ac0a.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/11_60846d0b7ac0a.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=63_60846d0b79a4c.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/63_60846d0b79a4c.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/63_60846d0b79a4c.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/63_60846d0b79a4c.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=10_60846ce4d42a1.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/10_60846ce4d42a1.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/10_60846ce4d42a1.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/10_60846ce4d42a1.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=26_60846d0b79d53.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/26_60846d0b79d53.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/26_60846d0b79d53.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/26_60846d0b79d53.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=90_60846ce4d3225.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="left" data-html="true" data-content="<img style='width: 250px' src='__bgs__/90_60846ce4d3225.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/90_60846ce4d3225.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/90_60846ce4d3225.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=58_60846d60bb847.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/58_60846d60bb847.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/58_60846d60bb847.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/58_60846d60bb847.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=19_60846ce4d4069.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/19_60846ce4d4069.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/19_60846ce4d4069.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/19_60846ce4d4069.jpg" />
</div>
</a>
 </div>
<div class="col-md-3" style="float: right;">
<a href="?photo=30_60846d39abca5.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/30_60846d39abca5.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/30_60846d39abca5.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/30_60846d39abca5.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=85_60846ce4d37b8.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="left" data-html="true" data-content="<img style='width: 250px' src='__bgs__/85_60846ce4d37b8.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/85_60846ce4d37b8.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/85_60846ce4d37b8.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=5_60846d60bbc99.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/5_60846d60bbc99.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/5_60846d60bbc99.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/5_60846d60bbc99.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=89_60846d0b7adf0.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/89_60846d0b7adf0.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/89_60846d0b7adf0.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/89_60846d0b7adf0.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=23_60846ce4d3fab.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/23_60846ce4d3fab.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/23_60846ce4d3fab.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/23_60846ce4d3fab.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=11_60846d39ab718.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="left" data-html="true" data-content="<img style='width: 250px' src='__bgs__/11_60846d39ab718.jpg' />">
 <img width="100%" class="thumbnail" src="__bgs__/11_60846d39ab718.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/11_60846d39ab718.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=88_60846d39aba84.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/88_60846d39aba84.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/88_60846d39aba84.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/88_60846d39aba84.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=86_60846d60bb6db.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/86_60846d60bb6db.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/86_60846d60bb6db.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/86_60846d60bb6db.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=94_60846d39ac108.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/94_60846d39ac108.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/94_60846d39ac108.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/94_60846d39ac108.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=42_60846ce4d3c0f.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="left" data-html="true" data-content="<img style='width: 250px' src='__bgs__/42_60846ce4d3c0f.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/42_60846ce4d3c0f.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/42_60846ce4d3c0f.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=91_60846d39ab018.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/91_60846d39ab018.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/91_60846d39ab018.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/91_60846d39ab018.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=60_60846d39ac200.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/60_60846d39ac200.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/60_60846d39ac200.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/60_60846d39ac200.jpg" />
</div>
</a>
</div>
<div class="col-md-3" style="float: right;">
<a href="?photo=67_60846d60bc954.jpg&p=view" title="">
<div class="hidden-sm" style="height: 100%;overflow: hidden;" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img style='width: 250px' src='__bgs__/67_60846d60bc954.jpg' />">
<img width="100%" class="thumbnail" src="__bgs__/67_60846d60bc954.jpg" />
</div>
<div class="visible-sm" style="">
<img width="85%" class="thumbnail center-block" src="__bgs__/67_60846d60bc954.jpg" />
</div>
</a>
</div>
<div class="modal fade" id="login-temp" tabindex="-1" role="dialog">
<div class="modal-dialog modal-sm" role="document">
<form action="" method="post">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
<h4 class="modal-title">Admin Login</h4>
</div>
<div class="modal-body">
<div class="form-group">
<label for="exampleInputEmail1">User Name</label>
<input type="text" name="username" class="form-control" id="exampleInputEmail1" placeholder="Email">
</div>
<div class="form-group">
<label for="exampleInputPassword1">Password</label>
<input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
</div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
<button type="submit" class="btn btn-primary">Login</button>
</div>
</div>
</form>
</div>
</div> <script type="text/javascript">
            function login()
            {
                $('#login-temp').modal('show');
            }
        </script>
<div class="row text-center visible-lg">

<ins class="adsbygoogle" style="display:inline-block;width:728px;height:90px" data-ad-client="ca-pub-1148445499813917" data-ad-slot="1594837797"></ins>
<script>
    (adsbygoogle = window.adsbygoogle || []).push({});
    </script>
</div>
</div>
</body>
<div>
<div class="text-center">
<h1 id="site-title">
<a href="https://imasdar.com/" itemprop="url" rel="home" style="font-size: 15px;">
جميع الحقوق محفوظة لموقع مصدر.© - 2021
</a>

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-62910867-2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-62910867-2');
</script>
</h1>
</div>
</html>