 <!DOCTYPE html>
<!--[if IE 8]>
	<html class="ie ie8" dir="rtl" lang="ar"> <![endif]-->
<!--[if IE 9]>
	<html class="ie ie9" dir="rtl" lang="ar"> <![endif]-->
<!--[if gt IE 9]><!-->
<html dir="rtl" lang="ar"> <!--<![endif]-->
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="pingback" href="https://imasdar.com/xmlrpc.php" />
<script>
            var wpdm_site_url = 'https://imasdar.com/';
            var wpdm_home_url = 'https://imasdar.com/';
            var ajax_url = 'https://imasdar.com/wp-admin/admin-ajax.php';
            var ajaxurl = 'https://imasdar.com/wp-admin/admin-ajax.php';
            var wpdm_ajax_url = 'https://imasdar.com/wp-admin/admin-ajax.php';
            var wpdm_ajax_popup = '0';
        </script>
<meta name='robots' content='max-image-preview:large' />

<title>Page not found - مصدر</title>
<meta name="robots" content="noindex, follow" />
<meta property="og:locale" content="ar_AR" />
<meta property="og:title" content="Page not found - مصدر" />
<meta property="og:site_name" content="مصدر" />
<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":["Person","Organization"],"@id":"https://imasdar.com/#/schema/person/53d7e38456508b8620e43d64ebc61d09","name":"\u0645\u0635\u062f\u0631","image":{"@type":"ImageObject","@id":"https://imasdar.com/#personlogo","inLanguage":"ar","url":"https://secure.gravatar.com/avatar/fb06571d96c6e30995897f1fa1719bd3?s=96&d=mm&r=g","caption":"\u0645\u0635\u062f\u0631"},"logo":{"@id":"https://imasdar.com/#personlogo"},"sameAs":["https://imasdar.com"]},{"@type":"WebSite","@id":"https://imasdar.com/#website","url":"https://imasdar.com/","name":"\u0645\u0635\u062f\u0631","description":"\u0645\u0648\u0642\u0639 \u0645\u0635\u062f\u0631 \u0647\u064a \u0625\u062d\u062f\u0649 \u0645\u0628\u0627\u062f\u0631\u0627\u0629 \u0645\u0648\u0642\u0639 \u0627\u0644\u0645\u0639\u0644\u0645\u0629 \u0623\u0633\u0645\u0627\u0621 \u0644\u062e\u062f\u0645\u0629 \u0627\u0644\u0639\u0645\u0644\u064a\u0629 \u0627\u0644\u062a\u0639\u0644\u064a\u0645\u064a\u0629 \u0648\u064a\u0639\u062a\u0628\u0631\u0645\u0646\u0635\u0629 \u0631\u0642\u0645\u064a\u0629 \u062a\u062c\u0645\u0639 \u0635\u0648\u0631\u064b\u0627 \u0630\u0627\u062a \u062c\u0648\u062f\u0629 \u0639\u0627\u0644\u064a\u0629 \u0633\u0648\u0627\u0621 \u0627\u0644\u0645\u062a\u062d\u0631\u0643\u0629 \u0623\u0648 \u0627\u0644\u062b\u0627\u0628\u062a\u0629 \u0648\u062e\u0644\u0641\u064a\u0627\u062a \u062b\u0627\u0628\u062a\u0629 \u0648\u0645\u062a\u062d\u0631\u0643\u0629 \u0648\u0639\u0631\u0648\u0636 \u062a\u0642\u062f\u064a\u0645\u064a\u0629 \u062c\u0627\u0647\u0632\u0629 \u0644\u062a\u062c\u062f \u0645\u0627 \u062a\u062d\u062a\u0627\u062c\u0647 \u0644\u0627\u0646\u0634\u0627\u0621 \u0639\u0631\u0636 \u062a\u0642\u062f\u064a\u0645\u064a \u0631\u0627\u0626\u0639 \u064a\u062a\u0646\u0627\u0633\u0628\u0643 \u0645\u0639 \u0623\u0641\u0643\u0627\u0631\u0643.","publisher":{"@id":"https://imasdar.com/#/schema/person/53d7e38456508b8620e43d64ebc61d09"},"potentialAction":[{"@type":"SearchAction","target":"https://imasdar.com/?s={search_term_string}","query-input":"required name=search_term_string"}],"inLanguage":"ar"}]}</script>

<link rel='dns-prefetch' href='//use.fontawesome.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link href='https://fonts.gstatic.com' crossorigin rel='preconnect' />
<link rel="alternate" type="application/rss+xml" title="مصدر &laquo; الخلاصة" href="https://imasdar.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="مصدر &laquo; خلاصة التعليقات" href="https://imasdar.com/comments/feed/" />
<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='wp-block-library-rtl-css' href='https://imasdar.com/wp-includes/css/dist/block-library/style-rtl.min.css?ver=5.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='my-custom-block-frontend-css-css' href='https://imasdar.com/wp-content/plugins/wpdm-gutenberg-blocks/build/style.css?ver=5.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='wpdm-font-awesome-css' href='https://use.fontawesome.com/releases/v5.12.1/css/all.css?ver=5.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='wpdm-front-bootstrap-css' href='https://imasdar.com/wp-content/plugins/download-manager/assets/bootstrap/css/bootstrap.min.css?ver=5.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='wpdm-front-css' href='https://imasdar.com/wp-content/plugins/download-manager/assets/css/front.css?ver=5.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='search-filter-plugin-styles-css' href='https://imasdar.com/wp-content/plugins/search-filter-pro/public/assets/css/search-filter.min.css?ver=2.5.7' type='text/css' media='all' />
<link rel='stylesheet' id='better-framework-main-fonts-css' href='https://fonts.googleapis.com/css?family=Cairo:400,600,700%7CRoboto+Condensed:700%7CRoboto:500&#038;display=swap' type='text/css' media='all' />
<script type='text/javascript' src='https://imasdar.com/wp-includes/js/jquery/jquery.min.js?ver=3.5.1' id='jquery-core-js'></script>
<script type='text/javascript' src='https://imasdar.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' src='https://imasdar.com/wp-content/plugins/download-manager/assets/bootstrap/js/popper.min.js?ver=5.7.1' id='wpdm-poper-js'></script>
<script type='text/javascript' src='https://imasdar.com/wp-content/plugins/download-manager/assets/bootstrap/js/bootstrap.min.js?ver=5.7.1' id='wpdm-front-bootstrap-js'></script>
<script type='text/javascript' id='frontjs-js-extra'>
/* <![CDATA[ */
var wpdm_url = {"home":"https:\/\/imasdar.com\/","site":"https:\/\/imasdar.com\/","ajax":"https:\/\/imasdar.com\/wp-admin\/admin-ajax.php"};
var wpdm_asset = {"bsversion":"","spinner":"<i class=\"fas fa-sun fa-spin\"><\/i>"};
/* ]]> */
</script>
<script type='text/javascript' src='https://imasdar.com/wp-content/plugins/download-manager/assets/js/front.js?ver=5.3.5' id='frontjs-js'></script>
<script type='text/javascript' id='search-filter-plugin-build-js-extra'>
/* <![CDATA[ */
var SF_LDATA = {"ajax_url":"https:\/\/imasdar.com\/wp-admin\/admin-ajax.php","home_url":"https:\/\/imasdar.com\/","extensions":[]};
/* ]]> */
</script>
<script type='text/javascript' src='https://imasdar.com/wp-content/plugins/search-filter-pro/public/assets/js/search-filter-build.min.js?ver=2.5.7' id='search-filter-plugin-build-js'></script>
<script type='text/javascript' src='https://imasdar.com/wp-content/plugins/search-filter-pro/public/assets/js/chosen.jquery.min.js?ver=2.5.7' id='search-filter-plugin-chosen-js'></script>
<!--[if lt IE 9]>
<script type='text/javascript' src='https://imasdar.com/wp-content/plugins/better-adsmanager/includes/libs/better-framework/assets/js/html5shiv.min.js?ver=3.11.14' id='bf-html5shiv-js'></script>
<![endif]-->
<!--[if lt IE 9]>
<script type='text/javascript' src='https://imasdar.com/wp-content/plugins/better-adsmanager/includes/libs/better-framework/assets/js/respond.min.js?ver=3.11.14' id='bf-respond-js'></script>
<![endif]-->
<link rel="https://api.w.org/" href="https://imasdar.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://imasdar.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://imasdar.com/wp-includes/wlwmanifest.xml" />
<link rel="preconnect" href="https://cdnjs.cloudflare.com"><meta property="og:image" content="https://imasdar.com/wp-content/uploads/2021/05/العيد-فرحة-445176751.png" /><meta property="og:title" content='عيد الفطر المبارك' />
<meta property="og:description" content='' />
<meta name="twitter:card" content='summary_large_image' />
<meta name="twitter:title" content='عيد الفطر المبارك' />
<meta name="twitter:description" content='' /><meta name="twitter:image" content="https://imasdar.com/wp-content/uploads/2021/05/العيد-فرحة-445176751.png" /><script data-ad-client="ca-pub-1148445499813917" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script src="https://imasdar.com/wpsafelink.js"></script>
<link rel="shortcut icon" href="https://imasdar.com/wp-content/uploads/2021/03/MasdarLogo.png"><meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress." />
<script type="application/ld+json">{
    "@context": "http://schema.org/",
    "@type": "Organization",
    "@id": "#organization",
    "logo": {
        "@type": "ImageObject",
        "url": "https://imasdar.com/wp-content/uploads/2021/01/logo-3.png"
    },
    "url": "https://imasdar.com/",
    "name": "\u0645\u0635\u062f\u0631",
    "description": "\u0645\u0648\u0642\u0639 \u0645\u0635\u062f\u0631 \u0647\u064a \u0625\u062d\u062f\u0649 \u0645\u0628\u0627\u062f\u0631\u0627\u0629 \u0645\u0648\u0642\u0639 \u0627\u0644\u0645\u0639\u0644\u0645\u0629 \u0623\u0633\u0645\u0627\u0621 \u0644\u062e\u062f\u0645\u0629 \u0627\u0644\u0639\u0645\u0644\u064a\u0629 \u0627\u0644\u062a\u0639\u0644\u064a\u0645\u064a\u0629 \u0648\u064a\u0639\u062a\u0628\u0631\u0645\u0646\u0635\u0629 \u0631\u0642\u0645\u064a\u0629 \u062a\u062c\u0645\u0639 \u0635\u0648\u0631\u064b\u0627 \u0630\u0627\u062a \u062c\u0648\u062f\u0629 \u0639\u0627\u0644\u064a\u0629 \u0633\u0648\u0627\u0621 \u0627\u0644\u0645\u062a\u062d\u0631\u0643\u0629 \u0623\u0648 \u0627\u0644\u062b\u0627\u0628\u062a\u0629 \u0648\u062e\u0644\u0641\u064a\u0627\u062a \u062b\u0627\u0628\u062a\u0629 \u0648\u0645\u062a\u062d\u0631\u0643\u0629 \u0648\u0639\u0631\u0648\u0636 \u062a\u0642\u062f\u064a\u0645\u064a\u0629 \u062c\u0627\u0647\u0632\u0629 \u0644\u062a\u062c\u062f \u0645\u0627 \u062a\u062d\u062a\u0627\u062c\u0647 \u0644\u0627\u0646\u0634\u0627\u0621 \u0639\u0631\u0636 \u062a\u0642\u062f\u064a\u0645\u064a \u0631\u0627\u0626\u0639 \u064a\u062a\u0646\u0627\u0633\u0628\u0643 \u0645\u0639 \u0623\u0641\u0643\u0627\u0631\u0643."
}</script>
<script type="application/ld+json">{
    "@context": "http://schema.org/",
    "@type": "WebSite",
    "name": "\u0645\u0635\u062f\u0631",
    "alternateName": "\u0645\u0648\u0642\u0639 \u0645\u0635\u062f\u0631 \u0647\u064a \u0625\u062d\u062f\u0649 \u0645\u0628\u0627\u062f\u0631\u0627\u0629 \u0645\u0648\u0642\u0639 \u0627\u0644\u0645\u0639\u0644\u0645\u0629 \u0623\u0633\u0645\u0627\u0621 \u0644\u062e\u062f\u0645\u0629 \u0627\u0644\u0639\u0645\u0644\u064a\u0629 \u0627\u0644\u062a\u0639\u0644\u064a\u0645\u064a\u0629 \u0648\u064a\u0639\u062a\u0628\u0631\u0645\u0646\u0635\u0629 \u0631\u0642\u0645\u064a\u0629 \u062a\u062c\u0645\u0639 \u0635\u0648\u0631\u064b\u0627 \u0630\u0627\u062a \u062c\u0648\u062f\u0629 \u0639\u0627\u0644\u064a\u0629 \u0633\u0648\u0627\u0621 \u0627\u0644\u0645\u062a\u062d\u0631\u0643\u0629 \u0623\u0648 \u0627\u0644\u062b\u0627\u0628\u062a\u0629 \u0648\u062e\u0644\u0641\u064a\u0627\u062a \u062b\u0627\u0628\u062a\u0629 \u0648\u0645\u062a\u062d\u0631\u0643\u0629 \u0648\u0639\u0631\u0648\u0636 \u062a\u0642\u062f\u064a\u0645\u064a\u0629 \u062c\u0627\u0647\u0632\u0629 \u0644\u062a\u062c\u062f \u0645\u0627 \u062a\u062d\u062a\u0627\u062c\u0647 \u0644\u0627\u0646\u0634\u0627\u0621 \u0639\u0631\u0636 \u062a\u0642\u062f\u064a\u0645\u064a \u0631\u0627\u0626\u0639 \u064a\u062a\u0646\u0627\u0633\u0628\u0643 \u0645\u0639 \u0623\u0641\u0643\u0627\u0631\u0643.",
    "url": "https://imasdar.com/"
}</script>
<link rel='stylesheet' id='better-google-custom-search' href='https://imasdar.com/wp-content/plugins/better-google-custom-search/css/better-google-custom-search.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='bs-icons' href='https://imasdar.com/wp-content/plugins/better-adsmanager/includes/libs/better-framework/assets/css/bs-icons.css' type='text/css' media='all' />
<link rel='stylesheet' id='better-social-counter' href='https://imasdar.com/wp-content/plugins/better-social-counter/css/style.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='better-social-counter-rtl' href='https://imasdar.com/wp-content/plugins/better-social-counter/css/rtl.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='bf-slick' href='https://imasdar.com/wp-content/plugins/better-adsmanager/includes/libs/better-framework/assets/css/slick.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='blockquote-pack-pro' href='https://imasdar.com/wp-content/plugins/blockquote-pack-pro/css/blockquote-pack.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='blockquote-pack-rtl' href='https://imasdar.com/wp-content/plugins/blockquote-pack-pro/css/blockquote-pack-rtl.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='smart-lists-pack-pro' href='https://imasdar.com/wp-content/plugins/smart-lists-pack-pro/css/smart-lists-pack.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='smart-lists-pack-rtl' href='https://imasdar.com/wp-content/plugins/smart-lists-pack-pro/css/smart-lists-pack-rtl.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='pretty-photo' href='https://imasdar.com/wp-content/plugins/better-adsmanager/includes/libs/better-framework/assets/css/pretty-photo.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='theme-libs' href='https://imasdar.com/wp-content/themes/publisher/css/theme-libs.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='fontawesome' href='https://imasdar.com/wp-content/plugins/better-adsmanager/includes/libs/better-framework/assets/css/font-awesome.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='publisher' href='https://imasdar.com/wp-content/themes/publisher/style-7.9.0.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='publisher-rtl' href='https://imasdar.com/wp-content/themes/publisher/rtl.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='vc-rtl-grid' href='https://imasdar.com/wp-content/themes/publisher//css/vc-rtl-grid.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='publisher-theme-travel-guides' href='https://imasdar.com/wp-content/themes/publisher/includes/styles/travel-guides/style.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='7.9.0-1619912733' href='https://imasdar.com/wp-content/bs-booster-cache/d2bf08a552014f3f9e0290afa6591b86.css' type='text/css' media='all' />

<style>
.searchandfilter ul li.sf-field-reset,
.searchandfilter ul li.sf-field-submit {
  display: inline-block;
}


.w3eden .wpdm-all-categories a.wpdm-scat {
    font-weight: 400;
    font-size: 9pt;
    margin-right: 10px;
    /* opacity: .6; */
    display: inline-grid;
}

.listing-item-grid-1 .featured .img-holder {

background-position: center center!important;
    background-size: 100% 100%;
}

.section-heading.sh-t1 .h-text {
background: 0 !important;
}

.archive-title, .bs-listing, .bs-shortcode, .bs-vc-block, .bs-vc-content .better-studio-shortcode, .widget {
    background: 0 !important;
    padding: 20px;
    box-shadow: 0 4px 5px 0 rgba(0,0,0,.09);
}

   
.w3eden .btn.btn-secondary, .w3eden .flat-default, .w3eden .flat-default.btn-bordered:hover {
    
    border-color:#f5f5f5;
    color: #cb46e2;
    background-color:#ffffff;
}

.btn.btn-xs {
    height: 40px;
    line-height: 30px;
}

.w3eden .btn.btn-xs {
    border-radius: 0.5px;
    padding: 4px 8px;
    font-size: 12px;
    font-family:cairo;
}
    
 

</style>

<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><meta name="generator" content="WordPress Download Manager 5.3.5" />
<link href="https://fonts.googleapis.com/css?family=Rubik" rel="stylesheet">
<style>
            .w3eden .fetfont,
            .w3eden .btn,
            .w3eden .btn.wpdm-front h3.title,
            .w3eden .wpdm-social-lock-box .IN-widget a span:last-child,
            .w3eden #xfilelist .panel-heading,
            .w3eden .wpdm-frontend-tabs a,
            .w3eden .alert:before,
            .w3eden .panel .panel-heading,
            .w3eden .discount-msg,
            .w3eden .panel.dashboard-panel h3,
            .w3eden #wpdm-dashboard-sidebar .list-group-item,
            .w3eden #package-description .wp-switch-editor,
            .w3eden .w3eden.author-dashbboard .nav.nav-tabs li a,
            .w3eden .wpdm_cart thead th,
            .w3eden #csp .list-group-item,
            .w3eden .modal-title {
                font-family: Rubik, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
                text-transform: uppercase;
                font-weight: 700;
            }
            .w3eden #csp .list-group-item {
                text-transform: unset;
            }


        </style>
<style>
        /* WPDM Link Template Styles */        </style>
<style>

            :root {
                --color-primary: #4a8eff;
                --color-primary-rgb: 74, 142, 255;
                --color-primary-hover: #4a8eff;
                --color-primary-active: #4a8eff;
                --color-secondary: #6c757d;
                --color-secondary-rgb: 108, 117, 125;
                --color-secondary-hover: #6c757d;
                --color-secondary-active: #6c757d;
                --color-success: #18ce0f;
                --color-success-rgb: 24, 206, 15;
                --color-success-hover: #18ce0f;
                --color-success-active: #18ce0f;
                --color-info: #2CA8FF;
                --color-info-rgb: 44, 168, 255;
                --color-info-hover: #2CA8FF;
                --color-info-active: #2CA8FF;
                --color-warning: #FFB236;
                --color-warning-rgb: 255, 178, 54;
                --color-warning-hover: #FFB236;
                --color-warning-active: #FFB236;
                --color-danger: #ff5062;
                --color-danger-rgb: 255, 80, 98;
                --color-danger-hover: #ff5062;
                --color-danger-active: #ff5062;
                --color-green: #30b570;
                --color-blue: #0073ff;
                --color-purple: #8557D3;
                --color-red: #ff5062;
                --color-muted: rgba(69, 89, 122, 0.6);
                --wpdm-font: "Rubik", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
            }

            .wpdm-download-link.btn.btn-primary {
                border-radius: 4px;
            }


        </style>
<noscript><style id="rocket-lazyload-nojs-css">.rll-youtube-player, [data-lazy-src]{display:none !important;}</style></noscript> </head>
<body class="rtl error404 bs-theme bs-publisher bs-publisher-travel-guides active-light-box bs-vc-rtl-grid close-rh page-layout-2-col page-layout-2-col-left full-width active-sticky-sidebar main-menu-sticky-smart main-menu-full-width active-ajax-search  wpb-js-composer js-comp-ver-6.4.2 vc_responsive bs-ll-a" dir="rtl">
<div class="main-wrap content-main-wrap">
<header id="header" class="site-header header-style-8 full-width" itemscope="itemscope" itemtype="https://schema.org/WPHeader">
<section class="topbar topbar-style-1 hidden-xs hidden-xs">
<div class="content-wrap">
<div class="container">
<div class="topbar-inner clearfix">
<div class="section-links">
<div class="  better-studio-shortcode bsc-clearfix better-social-counter style-button not-colored in-4-col">
<ul class="social-list bsc-clearfix"><li class="social-item facebook"><a href="https://www.facebook.com/masdarsite" target="_blank"> <i class="item-icon bsfi-facebook"></i><span class="item-title"> Likes </span> </a> </li> <li class="social-item pinterest"><a href="https://www.pinterest.com/teacherafirwana" target="_blank"> <i class="item-icon bsfi-pinterest"></i><span class="item-title"> Followers </span> </a> </li> </ul>
</div>
<a class="topbar-sign-in behind-social" data-toggle="modal" data-target="#bsLoginModal">
<i class="fa fa-user-circle"></i> تسجيل الدخول </a>
<div class="modal sign-in-modal fade" id="bsLoginModal" tabindex="-1" role="dialog" style="display: none">
<div class="modal-dialog" role="document">
<div class="modal-content">
<span class="close-modal" data-dismiss="modal" aria-label="Close"><i class="fa fa-close"></i></span>
<div class="modal-body">
<div id="form_1808_" class="bs-shortcode bs-login-shortcode ">
<div class="bs-login bs-type-login" style="display:none">
<div class="bs-login-panel bs-login-sign-panel bs-current-login-panel">
<form name="loginform" action="https://imasdar.com/wp-login.php" method="post">
<div class="login-header">
<span class="login-icon fa fa-user-circle main-color"></span>
<p>مرحبا، تسجيل الدخول إلى حسابك.</p>
</div>
<div class="login-field login-username">
<input type="text" name="log" id="form_1808_user_login" class="input" value="" size="20" placeholder="اسم المستخدم أو البريد الالكتروني..." required />
</div>
<div class="login-field login-password">
<input type="password" name="pwd" id="form_1808_user_pass" class="input" value="" size="20" placeholder="كلمة المرور..." required />
</div>
<div class="login-field">
<a href="https://imasdar.com/wp-login.php?action=lostpassword&redirect_to=https%3A%2F%2Fimasdar.com%2Fcrd%2Feid%2F2%2FPopover%2520requires%2520tooltip.js" class="go-reset-panel">نسيت كلمة المرور؟</a>
<span class="login-remember">
<input class="remember-checkbox" name="rememberme" type="checkbox" id="form_1808_rememberme" value="forever" />
<label class="remember-label">تذكرني</label>
</span>
</div>
<div class="login-field login-submit">
<input type="submit" name="wp-submit" class="button-primary login-btn" value="تسجيل الدخول" />
<input type="hidden" name="redirect_to" value="https://imasdar.com/crd/eid/2/Popover%20requires%20tooltip.js" />
</div>
</form>
</div>
<div class="bs-login-panel bs-login-reset-panel">
<span class="go-login-panel"><i class="fa fa-angle-right"></i> تسجيل الدخول</span>
<div class="bs-login-reset-panel-inner">
<div class="login-header">
<span class="login-icon fa fa-support"></span>
<p>استعادة كلمة المرور الخاصة بك.</p>
<p>كلمة المرور سترسل إليك بالبريد الإلكتروني.</p>
</div>
<form name="lostpasswordform" id="form_1808_lostpasswordform" action="https://imasdar.com/wp-login.php?action=lostpassword" method="post">
<div class="login-field reset-username">
<input type="text" name="user_login" class="input" value="" placeholder="اسم المستخدم أو البريد الالكتروني..." required />
</div>
<div class="login-field reset-submit">
<input type="hidden" name="redirect_to" value="" />
<input type="submit" name="wp-submit" class="login-btn" value="إرسال كلمة المرور" />
</div>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="section-menu">
<div id="menu-top" class="menu top-menu-wrapper" role="navigation" itemscope="itemscope" itemtype="https://schema.org/SiteNavigationElement">
<nav class="top-menu-container">
<ul id="top-navigation" class="top-menu menu clearfix bsm-pure">
<li id="menu-item-5219" class="menu-have-icon menu-icon-type-custom-icon menu-icon-type-fontawesome menu-item menu-item-type-custom menu-item-object-custom better-anim-fade menu-item-5219"><a href="https://mrsasmaa.com/"><i class="bf-icon bf-custom-icon "><img style="max-width:25px" src="https://imasdar.com/wp-content/uploads/2021/01/12sq-1.png"></i>المعلمة أسماء</a></li>
</ul>
</nav>
</div>
</div>
</div>
</div>
</div>
</section>
<div class="content-wrap">
<div class="container">
<div class="header-inner clearfix">
<div id="site-branding" class="site-branding">
<p id="site-title" class="logo h1 img-logo">
<a href="https://imasdar.com/" itemprop="url" rel="home">
<img id="site-logo" src="https://imasdar.com/wp-content/uploads/2021/01/logo-3.png" alt="مصدر" />
<span class="site-title">مصدر - موقع مصدر هي إحدى مبادراة موقع المعلمة أسماء لخدمة العملية التعليمية ويعتبرمنصة رقمية تجمع صورًا ذات جودة عالية سواء المتحركة أو الثابتة وخلفيات ثابتة ومتحركة وعروض تقديمية جاهزة لتجد ما تحتاجه لانشاء عرض تقديمي رائع يتناسبك مع أفكارك.</span>
</a>
</p>
</div>
<nav id="menu-main" class="menu main-menu-container  show-search-item menu-actions-btn-width-1" role="navigation" itemscope="itemscope" itemtype="https://schema.org/SiteNavigationElement">
<div class="menu-action-buttons width-1">
<div class="search-container close">
<span class="search-handler"><i class="fa fa-search"></i></span>
<div class="search-box clearfix">
<form role="search" method="get" class="search-form clearfix" action="https://imasdar.com">
<input type="search" class="search-field" placeholder="بحث..." value="" name="s" title="البحث عن:" autocomplete="off">
<input type="submit" class="search-submit" value="بحث">
</form>
</div>
</div>
</div>
<ul id="main-navigation" class="main-menu menu bsm-pure clearfix">
<li id="menu-item-5003" class="menu-have-icon menu-icon-type-fontawesome menu-item menu-item-type-post_type menu-item-object-page menu-item-home better-anim-fade menu-item-5003"><a href="https://imasdar.com/"><i class="bf-icon  fa fa-home"></i>الرئيسية</a></li>
<li id="menu-item-7347" class="menu-have-icon menu-icon-type-fontawesome menu-item menu-item-type-taxonomy menu-item-object-category menu-term-1177 better-anim-fade menu-item-7347"><a href="https://imasdar.com/category/%d8%a7%d9%84%d8%a3%d9%81%d9%83%d8%a7%d8%b1/"><i class="bf-icon  fa fa-lightbulb-o"></i>الأفكار</a></li>
<li id="menu-item-5002" class="menu-have-icon menu-icon-type-fontawesome menu-item menu-item-type-post_type menu-item-object-page better-anim-fade menu-item-5002"><a href="https://imasdar.com/%d8%a7%d9%84%d8%a3%d9%82%d8%b3%d8%a7%d9%85-%d8%a7%d9%84%d8%b1%d8%a6%d9%8a%d8%b3%d9%8a%d8%a9/"><i class="bf-icon  fa fa-briefcase"></i>الأقسام</a></li>
<li id="menu-item-5042" class="menu-have-icon menu-icon-type-fontawesome menu-item menu-item-type-post_type menu-item-object-page better-anim-fade menu-item-5042"><a href="https://imasdar.com/%d8%a7%d9%84%d8%b5%d9%88%d8%b1-%d8%a7%d9%84%d8%ab%d8%a7%d8%a8%d8%aa%d8%a9-%d9%88%d8%a7%d9%84%d9%85%d8%aa%d8%ad%d8%b1%d9%83%d8%a9/"><i class="bf-icon  fa fa-image"></i>الصور</a></li>
<li id="menu-item-5948" class="menu-have-icon menu-icon-type-fontawesome menu-item menu-item-type-post_type menu-item-object-page better-anim-fade menu-item-5948"><a href="https://imasdar.com/%d8%a7%d9%84%d8%ae%d9%84%d9%81%d9%8a%d8%a7%d8%aa-%d8%a7%d9%84%d8%ab%d8%a7%d8%a8%d8%aa%d8%a9-%d9%88%d8%a7%d9%84%d9%85%d8%aa%d8%ad%d8%b1%d9%83%d8%a9/"><i class="bf-icon  fa fa-camera-retro"></i>الخلفيات</a></li>
<li id="menu-item-7855" class="menu-have-icon menu-icon-type-fontawesome menu-item menu-item-type-taxonomy menu-item-object-category menu-term-1355 better-anim-fade menu-item-7855"><a href="https://imasdar.com/category/%d8%a8%d8%b7%d8%a7%d9%82%d8%a7%d8%aa-%d8%aa%d9%87%d9%86%d8%a6%d8%a9/"><i class="bf-icon  fa fa-star-o"></i>بطاقات تهنئة</a></li>
</ul>
</nav>
</div>
</div>
</div>
</header>
<div class="rh-header clearfix light deferred-block-exclude">
<div class="rh-container clearfix">
<div class="menu-container close">
<span class="menu-handler"><span class="lines"></span></span>
</div>
<div class="logo-container rh-img-logo">
<a href="https://imasdar.com/" itemprop="url" rel="home">
<img src="https://imasdar.com/wp-content/uploads/2021/01/logo-3.png" alt="مصدر" /> </a>
</div>
</div>
</div>
<nav role="navigation" aria-label="Breadcrumbs" class="bf-breadcrumb clearfix bc-top-style"><div class="container bf-breadcrumb-container"><ul class="bf-breadcrumb-items" itemscope itemtype="http://schema.org/BreadcrumbList"><meta name="numberOfItems" content="2" /><meta name="itemListOrder" content="Ascending" /><li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="bf-breadcrumb-item bf-breadcrumb-begin"><a itemprop="item" href="https://imasdar.com" rel="home"><span itemprop="name">الصفحة الرئيسية</span></a><meta itemprop="position" content="1" /></li><li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="bf-breadcrumb-item bf-breadcrumb-end"><span itemprop="name">404 غير موجود</span><meta itemprop="item" content="https://imasdar.com/search/" /><meta itemprop="position" content="2" /></li></ul></div></nav> <div class="content-wrap">
<main id="content" class="content-container">
<div class="container layout-1-col layout-no-sidebar">
<div class="row main-section">
<div class="content-column content-404">
<div class="row first-row">
<div class="col-lg-12 text-404-section">
<p class="text-404 heading-typo">404</p>
</div>
<div class="col-lg-12 desc-section">
<h1 class="title-404">الصفحة غير موجودة!</h1>
<p>نحن آسفون، لا يمكن العثور على الصفحة التي كنت تبحث عنها. على الارجح هناك خطأ ولكن يجب أن نعرف عن ذلك، وسنحاول إصلاحه. في هذه الأثناء، حاول مرة أخرى من هذه الخيارات:</p>
<div class="action-links clearfix">
<script type="text/javascript">
                                        if (document.referrer) {
                                            document.write('<div class="search-action-container"><a href="' + document.referrer + '"><i class="fa fa-angle-double-right"></i> الذهاب إلى الصفحة السابقة</a></div>');
                                        }
									</script>
<div class="search-action-container">
<a href="https://imasdar.com/"><i class="fa fa-angle-double-right"></i> الذهاب إلى الصفحة الرئيسية </a>
</div>
</div>
</div>
</div>
<div class="row second-row">
<div class="col-lg-12">
<div class="top-line">
<form role="search" method="get" class="search-form clearfix" action="https://imasdar.com">
<input type="search" class="search-field" placeholder="بحث..." value="" name="s" title="البحث عن:" autocomplete="off">
<input type="submit" class="search-submit" value="بحث">
</form>
</div>
</div>
</div>
</div>
</div>
</div> 
</main>
</div>
<footer id="site-footer" class="site-footer full-width">
<div class="copy-footer">
<div class="content-wrap">
<div class="container">
<div class="row">
<div class="col-lg-12">
<div id="menu-footer" class="menu footer-menu-wrapper" role="navigation" itemscope="itemscope" itemtype="https://schema.org/SiteNavigationElement">
<nav class="footer-menu-container">
<ul id="footer-navigation" class="footer-menu menu clearfix">
<li id="menu-item-5912" class="menu-item menu-item-type-post_type menu-item-object-page better-anim-fade menu-item-5912"><a href="https://imasdar.com/%d8%a7%d9%84%d8%a3%d9%82%d8%b3%d8%a7%d9%85-%d8%a7%d9%84%d8%b1%d8%a6%d9%8a%d8%b3%d9%8a%d8%a9/">الأقسام الرئيسية</a></li>
<li id="menu-item-5911" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-privacy-policy better-anim-fade menu-item-5911"><a href="https://imasdar.com/privacy-policy/">سياسة الخصوصية</a></li>
</ul>
</nav>
</div>
</div>
</div>
<div class="row footer-copy-row">
<div class="copy-1 col-lg-6 col-md-6 col-sm-6 col-xs-12">
جميع الحقوق محفوظة مصدر.© - 2021 . </div>
<div class="copy-2 col-lg-6 col-md-6 col-sm-6 col-xs-12">
</div>
</div>
</div>
</div>
</div>
</footer>
</div>
<div class="bs-wrap-gdpr-law bs-wrap-gdpr-law-close">
<div class="bs-gdpr-law">
<p>
يستخدم هذا الموقع ملفات تعريف الارتباط لتحسين تجربتك. سنفترض أنك موافق على ذلك ، ولكن يمكنك إلغاء الاشتراك إذا كنت ترغب في ذلك.
<a class="bs-gdpr-accept" href="#" data-cookie="show">قبول</a>
<a class="bs-gdpr-more" href="#">قراءة المزيد</a>
</p>
</div>
</div>
<span class="back-top"><i class="fa fa-arrow-up"></i></span>
<script>
                jQuery(function($){

                    
                                    });
            </script>
<div id="fb-root"></div>
<style>

            .wpdm-popover {
                transition: all ease-in-out 400ms;
                position: relative;display: inline-block;
            }

            .wpdm-popover .wpdm-hover-card {
                position: absolute;
                left: 0;
                bottom: 50px;
                width: 100%;
                transition: all ease-in-out 400ms;
                margin-bottom: 28px;
                opacity: 0;
                z-index: -999999;
            }

            .wpdm-popover:hover .wpdm-hover-card {
                transition: all ease-in-out 400ms;
                opacity: 1;
                z-index: 999999;
                bottom: 0px;
            }

            .wpdm-popover .wpdm-hover-card.hover-preview img {
                width: 104px;
                border-radius: 3px;
            }

            .wpdm-popover .card .card-footer{
                background: rgba(0,0,0,0.02);
            }

            .packinfo {
                margin-top: 10px;
                font-weight: 400;
                font-size: 14px;
            }
        </style>
<script>
            jQuery(function ($) {
                $('a[data-show-on-hover]').on('hover', function () {
                    $($(this).data('show-on-hover')).fadeIn();
                });
            });
        </script>
<div class="w3eden">
<div id="wpdm-popup-link" class="modal fade">
<div class="modal-dialog" style="width: 750px">
<div class="modal-content">
<div class="modal-header">
 <h4 class="modal-title"></h4>
</div>
<div class="modal-body" id='wpdm-modal-body'>
<p class="wpdm-placeholder">
[ Placeholder content for popup link ]
<a href="https://www.wpdownloadmanager.com/">WordPress Download Manager - Best Download Management Plugin</a>
</p>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
</div>
</div>
</div>
</div>
</div>
<script language="JavaScript">
            <!--
            jQuery(function () {
                jQuery('.wpdm-popup-link').click(function (e) {
                    e.preventDefault();
                    jQuery('#wpdm-popup-link .modal-title').html(jQuery(this).data('title'));
                    jQuery('#wpdm-modal-body').html('<i class="icon"><img align="left" style="margin-top: -1px" src="https://imasdar.com/wp-content/plugins/download-manager/assets/images/loading-new.gif" /></i>&nbsp;Please Wait...');
                    jQuery('#wpdm-popup-link').modal('show');
                    jQuery.post(this.href,{mode:'popup'}, function (res) {
                        jQuery('#wpdm-modal-body').html(res);
                    });
                    return false;
                });
            });
            //-->
        </script>
<style type="text/css">
            #wpdm-modal-body img {
                max-width: 100% !important;
            }
            .wpdm-placeholder{
                display: none;
            }
        </style>

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-62910867-2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-62910867-2');
</script>
<style type="text/css" media="print">

				* {
					display: none !important;
				}

				body, html {
					display: block !important;
				}

				#cpp-print-disabled {
					top: 0;
					left: 0;
					color: #111;
					width: 100%;
					height: 100%;
					min-height: 400px;
					z-index: 9999;
					position: fixed;
					font-size: 30px;
					text-align: center;
					background: #fcfcfc;

					padding-top: 200px;

					display: block !important;
				}
			</style>
<div id="cpp-print-disabled" style="display: none;">
You cannot print contents of this website. </div>
<script id='publisher-theme-pagination-js-extra'>
var bs_pagination_loc = {"loading":"<div class=\"bs-loading\"><div><\/div><div><\/div><div><\/div><div><\/div><div><\/div><div><\/div><div><\/div><div><\/div><div><\/div><\/div>"};
</script>
<script id='smart-lists-pack-pro-js-extra'>
var bs_smart_lists_loc = {"translations":{"nav_next":"Next","nav_prev":"Prev","trans_x_of_y":"%1$s of %2$s","trans_page_x_of_y":"Page %1$s of %2$s"}};
</script>
<script id='content-protector-pack-js-extra'>
var cpp_loc = {"opt-1":[true,true],"opt-2":["",true,true,"",["ctrl_a","ctrl_c","ctrl_x","ctrl_v","ctrl_s","ctrl_u","ctrl_p","cmd_a","cmd_c","cmd_x","cmd_v","cmd_s","cmd_u","cmd_p","cmd_alt_i","ctrl_shift_i","cmd_alt_u"],true,true,["imasdar.com"],""],"opt-3":["message","Iframe requests are blocked.",""]};
</script>
<script id='publisher-js-extra'>
var publisher_theme_global_loc = {"page":{"boxed":"full-width"},"header":{"style":"style-8","boxed":"full-width"},"ajax_url":"https:\/\/imasdar.com\/wp-admin\/admin-ajax.php","loading":"<div class=\"bs-loading\"><div><\/div><div><\/div><div><\/div><div><\/div><div><\/div><div><\/div><div><\/div><div><\/div><div><\/div><\/div>","translations":{"tabs_all":"\u0627\u0644\u0643\u0644","tabs_more":"\u0627\u0644\u0645\u0632\u064a\u062f","lightbox_expand":"\u062a\u0648\u0633\u064a\u0639 \u0627\u0644\u0635\u0648\u0631\u0629","lightbox_close":"\u0642\u0631\u064a\u0628"},"lightbox":{"not_classes":""},"main_menu":{"more_menu":"enable"},"top_menu":{"more_menu":"enable"},"skyscraper":{"sticky_gap":30,"sticky":true,"position":""},"share":{"more":true},"refresh_googletagads":"1","get_locale":"ar","notification":{"subscribe_msg":"\u0645\u0646 \u062e\u0644\u0627\u0644 \u0627\u0644\u0646\u0642\u0631 \u0639\u0644\u0649 \u0632\u0631 \u0627\u0644\u0627\u0634\u062a\u0631\u0627\u0643 \u060c \u0644\u0646 \u062a\u0641\u0648\u062a\u0643 \u0627\u0644\u0645\u0648\u0627\u062f \u0627\u0644\u062c\u062f\u064a\u062f\u0629!","subscribed_msg":"\u0623\u0646\u062a \u0645\u0634\u062a\u0631\u0643 \u0641\u064a \u0627\u0644\u0625\u062e\u0637\u0627\u0631\u0627\u062a","subscribe_btn":"\u0627\u0644\u0627\u0634\u062a\u0631\u0627\u0643","subscribed_btn":"\u0625\u0644\u063a\u0627\u0621 \u0627\u0644\u0627\u0634\u062a\u0631\u0627\u0643"}};
var publisher_theme_ajax_search_loc = {"ajax_url":"https:\/\/imasdar.com\/wp-admin\/admin-ajax.php","previewMarkup":"<div class=\"ajax-search-results-wrapper ajax-search-no-product\">\n\t<div class=\"ajax-search-results\">\n\t\t<div class=\"ajax-ajax-posts-list\">\n\t\t\t<div class=\"ajax-posts-column\">\n\t\t\t\t<div class=\"clean-title heading-typo\">\n\t\t\t\t\t<span>\u0627\u0644\u0645\u0634\u0627\u0631\u0643\u0627\u062a<\/span>\n\t\t\t\t<\/div>\n\t\t\t\t<div class=\"posts-lists\" data-section-name=\"posts\"><\/div>\n\t\t\t<\/div>\n\t\t<\/div>\n\t\t<div class=\"ajax-taxonomy-list\">\n\t\t\t<div class=\"ajax-categories-columns\">\n\t\t\t\t<div class=\"clean-title heading-typo\">\n\t\t\t\t\t<span>\u0627\u0644\u062a\u0635\u0646\u064a\u0641\u0627\u062a<\/span>\n\t\t\t\t<\/div>\n\t\t\t\t<div class=\"posts-lists\" data-section-name=\"categories\"><\/div>\n\t\t\t<\/div>\n\t\t\t<div class=\"ajax-tags-columns\">\n\t\t\t\t<div class=\"clean-title heading-typo\">\n\t\t\t\t\t<span>\u0627\u0644\u0648\u0633\u0648\u0645<\/span>\n\t\t\t\t<\/div>\n\t\t\t\t<div class=\"posts-lists\" data-section-name=\"tags\"><\/div>\n\t\t\t<\/div>\n\t\t<\/div>\n\t<\/div>\n<\/div>\n","full_width":"0"};
</script>
<div class="rh-cover noscroll ">
<span class="rh-close"></span>
<div class="rh-panel rh-pm">
<div class="rh-p-h">
<span class="user-login">
<span class="user-avatar user-avatar-icon"><i class="fa fa-user-circle"></i></span>
تسجيل الدخول </span> </div>
<div class="rh-p-b">
<div class="rh-c-m clearfix"></div>
<form role="search" method="get" class="search-form" action="https://imasdar.com">
<input type="search" class="search-field" placeholder="بحث..." value="" name="s" title="البحث عن:" autocomplete="off">
<input type="submit" class="search-submit" value="">
</form>
</div>
</div>
<div class="rh-panel rh-p-u">
<div class="rh-p-h">
<span class="rh-back-menu"><i></i></span>
</div>
<div class="rh-p-b">
<div id="form_6131_" class="bs-shortcode bs-login-shortcode ">
<div class="bs-login bs-type-login" style="display:none">
<div class="bs-login-panel bs-login-sign-panel bs-current-login-panel">
<form name="loginform" action="https://imasdar.com/wp-login.php" method="post">
<div class="login-header">
<span class="login-icon fa fa-user-circle main-color"></span>
<p>مرحبا، تسجيل الدخول إلى حسابك.</p>
</div>
<div class="login-field login-username">
<input type="text" name="log" id="form_6131_user_login" class="input" value="" size="20" placeholder="اسم المستخدم أو البريد الالكتروني..." required />
</div>
<div class="login-field login-password">
<input type="password" name="pwd" id="form_6131_user_pass" class="input" value="" size="20" placeholder="كلمة المرور..." required />
</div>
<div class="login-field">
<a href="https://imasdar.com/wp-login.php?action=lostpassword&redirect_to=https%3A%2F%2Fimasdar.com%2Fcrd%2Feid%2F2%2FPopover%2520requires%2520tooltip.js" class="go-reset-panel">نسيت كلمة المرور؟</a>
<span class="login-remember">
<input class="remember-checkbox" name="rememberme" type="checkbox" id="form_6131_rememberme" value="forever" />
<label class="remember-label">تذكرني</label>
</span>
</div>
<div class="login-field login-submit">
<input type="submit" name="wp-submit" class="button-primary login-btn" value="تسجيل الدخول" />
<input type="hidden" name="redirect_to" value="https://imasdar.com/crd/eid/2/Popover%20requires%20tooltip.js" />
</div>
</form>
</div>
<div class="bs-login-panel bs-login-reset-panel">
<span class="go-login-panel"><i class="fa fa-angle-right"></i> تسجيل الدخول</span>
<div class="bs-login-reset-panel-inner">
<div class="login-header">
<span class="login-icon fa fa-support"></span>
<p>استعادة كلمة المرور الخاصة بك.</p>
<p>كلمة المرور سترسل إليك بالبريد الإلكتروني.</p>
</div>
<form name="lostpasswordform" id="form_6131_lostpasswordform" action="https://imasdar.com/wp-login.php?action=lostpassword" method="post">
<div class="login-field reset-username">
<input type="text" name="user_login" class="input" value="" placeholder="اسم المستخدم أو البريد الالكتروني..." required />
</div>
<div class="login-field reset-submit">
<input type="hidden" name="redirect_to" value="" />
<input type="submit" name="wp-submit" class="login-btn" value="إرسال كلمة المرور" />
</div>
</form>
</div>
</div>
</div>
</div> </div>
</div>
</div>
<script type='text/javascript' src='https://imasdar.com/wp-includes/js/jquery/jquery.form.min.js?ver=4.2.1' id='jquery-form-js'></script>
<script type='text/javascript' src='https://imasdar.com/wp-includes/js/jquery/ui/core.min.js?ver=1.12.1' id='jquery-ui-core-js'></script>
<script type='text/javascript' src='https://imasdar.com/wp-includes/js/jquery/ui/datepicker.min.js?ver=1.12.1' id='jquery-ui-datepicker-js'></script>
<script type='text/javascript' id='jquery-ui-datepicker-js-after'>
jQuery(document).ready(function(jQuery){jQuery.datepicker.setDefaults({"closeText":"\u0625\u063a\u0644\u0627\u0642","currentText":"\u0627\u0644\u064a\u0648\u0645","monthNames":["\u064a\u0646\u0627\u064a\u0631","\u0641\u0628\u0631\u0627\u064a\u0631","\u0645\u0627\u0631\u0633","\u0623\u0628\u0631\u064a\u0644","\u0645\u0627\u064a\u0648","\u064a\u0648\u0646\u064a\u0648","\u064a\u0648\u0644\u064a\u0648","\u0623\u063a\u0633\u0637\u0633","\u0633\u0628\u062a\u0645\u0628\u0631","\u0623\u0643\u062a\u0648\u0628\u0631","\u0646\u0648\u0641\u0645\u0628\u0631","\u062f\u064a\u0633\u0645\u0628\u0631"],"monthNamesShort":["\u064a\u0646\u0627\u064a\u0631","\u0641\u0628\u0631\u0627\u064a\u0631","\u0645\u0627\u0631\u0633","\u0623\u0628\u0631\u064a\u0644","\u0645\u0627\u064a\u0648","\u064a\u0648\u0646\u064a\u0648","\u064a\u0648\u0644\u064a\u0648","\u0623\u063a\u0633\u0637\u0633","\u0633\u0628\u062a\u0645\u0628\u0631","\u0623\u0643\u062a\u0648\u0628\u0631","\u0646\u0648\u0641\u0645\u0628\u0631","\u062f\u064a\u0633\u0645\u0628\u0631"],"nextText":"\u0627\u0644\u062a\u0627\u0644\u064a","prevText":"\u0627\u0644\u0633\u0627\u0628\u0642","dayNames":["\u0627\u0644\u0623\u062d\u062f","\u0627\u0644\u0625\u062b\u0646\u064a\u0646","\u0627\u0644\u062b\u0644\u0627\u062b\u0627\u0621","\u0627\u0644\u0623\u0631\u0628\u0639\u0627\u0621","\u0627\u0644\u062e\u0645\u064a\u0633","\u0627\u0644\u062c\u0645\u0639\u0629","\u0627\u0644\u0633\u0628\u062a"],"dayNamesShort":["\u0627\u0644\u0623\u062d\u062f","\u0627\u0644\u0623\u062b\u0646\u064a\u0646","\u0627\u0644\u062b\u0644\u0627\u062b\u0627\u0621","\u0627\u0644\u0623\u0631\u0628\u0639\u0627\u0621","\u0627\u0644\u062e\u0645\u064a\u0633","\u0627\u0644\u062c\u0645\u0639\u0629","\u0627\u0644\u0633\u0628\u062a"],"dayNamesMin":["\u062f","\u0646","\u062b","\u0623\u0631\u0628","\u062e","\u062c","\u0633"],"dateFormat":"MM d, yy","firstDay":0,"isRTL":true});});
</script>
<script type='text/javascript' id='rocket-browser-checker-js-after'>
"use strict";var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||!1,descriptor.configurable=!0,"value"in descriptor&&(descriptor.writable=!0),Object.defineProperty(target,descriptor.key,descriptor)}}return function(Constructor,protoProps,staticProps){return protoProps&&defineProperties(Constructor.prototype,protoProps),staticProps&&defineProperties(Constructor,staticProps),Constructor}}();function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor))throw new TypeError("Cannot call a class as a function")}var RocketBrowserCompatibilityChecker=function(){function RocketBrowserCompatibilityChecker(options){_classCallCheck(this,RocketBrowserCompatibilityChecker),this.passiveSupported=!1,this._checkPassiveOption(this),this.options=!!this.passiveSupported&&options}return _createClass(RocketBrowserCompatibilityChecker,[{key:"_checkPassiveOption",value:function(self){try{var options={get passive(){return!(self.passiveSupported=!0)}};window.addEventListener("test",null,options),window.removeEventListener("test",null,options)}catch(err){self.passiveSupported=!1}}},{key:"initRequestIdleCallback",value:function(){!1 in window&&(window.requestIdleCallback=function(cb){var start=Date.now();return setTimeout(function(){cb({didTimeout:!1,timeRemaining:function(){return Math.max(0,50-(Date.now()-start))}})},1)}),!1 in window&&(window.cancelIdleCallback=function(id){return clearTimeout(id)})}},{key:"isDataSaverModeOn",value:function(){return"connection"in navigator&&!0===navigator.connection.saveData}},{key:"supportsLinkPrefetch",value:function(){var elem=document.createElement("link");return elem.relList&&elem.relList.supports&&elem.relList.supports("prefetch")&&window.IntersectionObserver&&"isIntersecting"in IntersectionObserverEntry.prototype}},{key:"isSlowConnection",value:function(){return"connection"in navigator&&"effectiveType"in navigator.connection&&("2g"===navigator.connection.effectiveType||"slow-2g"===navigator.connection.effectiveType)}}]),RocketBrowserCompatibilityChecker}();
</script>
<script type='text/javascript' id='rocket-delay-js-js-after'>
(function() {
"use strict";var e=function(){function n(e,t){for(var r=0;r<t.length;r++){var n=t[r];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(e,n.key,n)}}return function(e,t,r){return t&&n(e.prototype,t),r&&n(e,r),e}}();function n(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}var t=function(){function r(e,t){n(this,r),this.attrName="data-rocketlazyloadscript",this.browser=t,this.options=this.browser.options,this.triggerEvents=e,this.userEventListener=this.triggerListener.bind(this)}return e(r,[{key:"init",value:function(){this._addEventListener(this)}},{key:"reset",value:function(){this._removeEventListener(this)}},{key:"_addEventListener",value:function(t){this.triggerEvents.forEach(function(e){return window.addEventListener(e,t.userEventListener,t.options)})}},{key:"_removeEventListener",value:function(t){this.triggerEvents.forEach(function(e){return window.removeEventListener(e,t.userEventListener,t.options)})}},{key:"_loadScriptSrc",value:function(){var r=this,e=document.querySelectorAll("script["+this.attrName+"]");0!==e.length&&Array.prototype.slice.call(e).forEach(function(e){var t=e.getAttribute(r.attrName);e.setAttribute("src",t),e.removeAttribute(r.attrName)}),this.reset()}},{key:"triggerListener",value:function(){this._loadScriptSrc(),this._removeEventListener(this)}}],[{key:"run",value:function(){RocketBrowserCompatibilityChecker&&new r(["keydown","mouseover","touchmove","touchstart","wheel"],new RocketBrowserCompatibilityChecker({passive:!0})).init()}}]),r}();t.run();
}());
</script>
<script type='text/javascript' id='rocket-preload-links-js-extra'>
/* <![CDATA[ */
var RocketPreloadLinksConfig = {"excludeUris":"\/(.+\/)?feed\/?.+\/?|\/(?:.+\/)?embed\/|\/(index\\.php\/)?wp\\-json(\/.*|$)|\/wp-admin\/|\/logout\/|\/wp-login.php","usesTrailingSlash":"1","imageExt":"jpg|jpeg|gif|png|tiff|bmp|webp|avif","fileExt":"jpg|jpeg|gif|png|tiff|bmp|webp|avif|php|pdf|html|htm","siteUrl":"https:\/\/imasdar.com","onHoverDelay":"100","rateThrottle":"3"};
/* ]]> */
</script>
<script type='text/javascript' id='rocket-preload-links-js-after'>
(function() {
"use strict";var r="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},e=function(){function i(e,t){for(var n=0;n<t.length;n++){var i=t[n];i.enumerable=i.enumerable||!1,i.configurable=!0,"value"in i&&(i.writable=!0),Object.defineProperty(e,i.key,i)}}return function(e,t,n){return t&&i(e.prototype,t),n&&i(e,n),e}}();function i(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}var t=function(){function n(e,t){i(this,n),this.browser=e,this.config=t,this.options=this.browser.options,this.prefetched=new Set,this.eventTime=null,this.threshold=1111,this.numOnHover=0}return e(n,[{key:"init",value:function(){!this.browser.supportsLinkPrefetch()||this.browser.isDataSaverModeOn()||this.browser.isSlowConnection()||(this.regex={excludeUris:RegExp(this.config.excludeUris,"i"),images:RegExp(".("+this.config.imageExt+")$","i"),fileExt:RegExp(".("+this.config.fileExt+")$","i")},this._initListeners(this))}},{key:"_initListeners",value:function(e){-1<this.config.onHoverDelay&&document.addEventListener("mouseover",e.listener.bind(e),e.listenerOptions),document.addEventListener("mousedown",e.listener.bind(e),e.listenerOptions),document.addEventListener("touchstart",e.listener.bind(e),e.listenerOptions)}},{key:"listener",value:function(e){var t=e.target.closest("a"),n=this._prepareUrl(t);if(null!==n)switch(e.type){case"mousedown":case"touchstart":this._addPrefetchLink(n);break;case"mouseover":this._earlyPrefetch(t,n,"mouseout")}}},{key:"_earlyPrefetch",value:function(t,e,n){var i=this,r=setTimeout(function(){if(r=null,0===i.numOnHover)setTimeout(function(){return i.numOnHover=0},1e3);else if(i.numOnHover>i.config.rateThrottle)return;i.numOnHover++,i._addPrefetchLink(e)},this.config.onHoverDelay);t.addEventListener(n,function e(){t.removeEventListener(n,e,{passive:!0}),null!==r&&(clearTimeout(r),r=null)},{passive:!0})}},{key:"_addPrefetchLink",value:function(i){return this.prefetched.add(i.href),new Promise(function(e,t){var n=document.createElement("link");n.rel="prefetch",n.href=i.href,n.onload=e,n.onerror=t,document.head.appendChild(n)}).catch(function(){})}},{key:"_prepareUrl",value:function(e){if(null===e||"object"!==(void 0===e?"undefined":r(e))||!1 in e||-1===["http:","https:"].indexOf(e.protocol))return null;var t=e.href.substring(0,this.config.siteUrl.length),n=this._getPathname(e.href,t),i={original:e.href,protocol:e.protocol,origin:t,pathname:n,href:t+n};return this._isLinkOk(i)?i:null}},{key:"_getPathname",value:function(e,t){var n=t?e.substring(this.config.siteUrl.length):e;return n.startsWith("/")||(n="/"+n),this._shouldAddTrailingSlash(n)?n+"/":n}},{key:"_shouldAddTrailingSlash",value:function(e){return this.config.usesTrailingSlash&&!e.endsWith("/")&&!this.regex.fileExt.test(e)}},{key:"_isLinkOk",value:function(e){return null!==e&&"object"===(void 0===e?"undefined":r(e))&&(!this.prefetched.has(e.href)&&e.origin===this.config.siteUrl&&-1===e.href.indexOf("?")&&-1===e.href.indexOf("#")&&!this.regex.excludeUris.test(e.href)&&!this.regex.images.test(e.href))}}],[{key:"run",value:function(){"undefined"!=typeof RocketPreloadLinksConfig&&new n(new RocketBrowserCompatibilityChecker({capture:!0,passive:!0}),RocketPreloadLinksConfig).init()}}]),n}();t.run();
}());
</script>
<script type='text/javascript' src='https://imasdar.com/wp-includes/js/wp-embed.min.js?ver=5.7.1' id='wp-embed-js'></script>
<script type='text/javascript' id='fifu-image-js-js-extra'>
/* <![CDATA[ */
var fifuImageVars = {"fifu_lazy":"","fifu_woo_lbox_enabled":"1","fifu_woo_zoom":"inline","fifu_is_product":"","fifu_is_flatsome_active":"","fifu_rest_url":"https:\/\/imasdar.com\/wp-json\/","fifu_nonce":"8242a198af"};
/* ]]> */
</script>
<script type='text/javascript' src='https://imasdar.com/wp-content/plugins/featured-image-from-url/includes/html/js/image.js?ver=3.5.8' id='fifu-image-js-js'></script>
<script type='text/javascript' async="async" src='https://imasdar.com/wp-content/bs-booster-cache/78de5304a9062fc32cdca16b9c8e98f7.js?ver=5.7.1' id='bs-booster-js'></script>
<script>
var pgqmyvbcn=function(t){"use strict";return{init:function(){0==pgqmyvbcn.ads_state()&&pgqmyvbcn.blocked_ads_fallback()},ads_state:function(){return void 0!==window.better_ads_adblock},blocked_ads_fallback:function(){var a=[];t(".pgqmyvbcn-container").each(function(){if("image"==t(this).data("type"))return 0;a.push({element_id:t(this).attr("id"),ad_id:t(this).data("adid")})}),a.length<1||jQuery.ajax({url:'https://imasdar.com/wp-admin/admin-ajax.php',type:"POST",data:{action:"better_ads_manager_blocked_fallback",ads:a},success:function(a){var e=JSON.parse(a);t.each(e.ads,function(a,e){t("#"+e.element_id).html(e.code)})}})}}}(jQuery);jQuery(document).ready(function(){pgqmyvbcn.init()});

</script>
<script>window.lazyLoadOptions={elements_selector:"img[data-lazy-src],.rocket-lazyload",data_src:"lazy-src",data_srcset:"lazy-srcset",data_sizes:"lazy-sizes",class_loading:"lazyloading",class_loaded:"lazyloaded",threshold:300,callback_loaded:function(element){if(element.tagName==="IFRAME"&&element.dataset.rocketLazyload=="fitvidscompatible"){if(element.classList.contains("lazyloaded")){if(typeof window.jQuery!="undefined"){if(jQuery.fn.fitVids){jQuery(element).parent().fitVids()}}}}}};window.addEventListener('LazyLoad::Initialized',function(e){var lazyLoadInstance=e.detail.instance;if(window.MutationObserver){var observer=new MutationObserver(function(mutations){var image_count=0;var iframe_count=0;var rocketlazy_count=0;mutations.forEach(function(mutation){for(i=0;i<mutation.addedNodes.length;i++){if(typeof mutation.addedNodes[i].getElementsByTagName!=='function'){continue}
if(typeof mutation.addedNodes[i].getElementsByClassName!=='function'){continue}
images=mutation.addedNodes[i].getElementsByTagName('img');is_image=mutation.addedNodes[i].tagName=="IMG";iframes=mutation.addedNodes[i].getElementsByTagName('iframe');is_iframe=mutation.addedNodes[i].tagName=="IFRAME";rocket_lazy=mutation.addedNodes[i].getElementsByClassName('rocket-lazyload');image_count+=images.length;iframe_count+=iframes.length;rocketlazy_count+=rocket_lazy.length;if(is_image){image_count+=1}
if(is_iframe){iframe_count+=1}}});if(image_count>0||iframe_count>0||rocketlazy_count>0){lazyLoadInstance.update()}});var b=document.getElementsByTagName("body")[0];var config={childList:!0,subtree:!0};observer.observe(b,config)}},!1)</script><script data-no-minify="1" async src="https://imasdar.com/wp-content/plugins/wp-rocket/assets/js/lazyload/16.1/lazyload.min.js"></script>
</body>
</html>